def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

def multiply(x, y):
    return x * y

def divide(x, y):
    try:
        result = x /y
        return result
    except ZeroDivisionError:
        print("Cannot perform division by zero.")

print("\nWelcome to the Calculator CLI!\n")
print("Choose an operation:")
print("[1] Add\n[2] Subtract\n[3] Multiply\n[4] Divide")

while True: 
   
   choice = input("\nEnter your choice (1/2/3/4): ")

   if not(choice.isdigit() and int(choice) in range(1,5)):
       print('Invalid input')
       continue
   
   num_1_str = input("Enter first number: ")
   while not(num_1_str.replace('.','', 0).isdigit()):
      num_1_str= input(f"Please enter valid digit for first number :")
      
        
       